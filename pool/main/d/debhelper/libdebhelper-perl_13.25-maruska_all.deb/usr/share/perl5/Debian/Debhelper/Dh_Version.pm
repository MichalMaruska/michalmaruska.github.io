package Debian::Debhelper::Dh_Version;
$version='13.25-maruska';
1