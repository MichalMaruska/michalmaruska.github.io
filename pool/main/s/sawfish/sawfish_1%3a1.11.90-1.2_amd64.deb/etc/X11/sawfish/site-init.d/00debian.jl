; load the sawfish defaults
(require 'sawfish-defaults)
; load gnome support
(require 'gnome)
