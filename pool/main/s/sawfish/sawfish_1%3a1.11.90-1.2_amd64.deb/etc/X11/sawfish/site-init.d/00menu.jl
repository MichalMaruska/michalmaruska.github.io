; load the debian menu
(require 'debian-menu)
; install it
(setq apps-menu debian-menu)
