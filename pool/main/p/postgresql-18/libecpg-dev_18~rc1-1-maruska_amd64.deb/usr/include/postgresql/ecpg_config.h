/* src/interfaces/ecpg/include/ecpg_config.h.  Generated from ecpg_config.h.in by configure.  */
/* Define to 1 to build client libraries as thread-safe code. */
#define ENABLE_THREAD_SAFETY 1

/* The size of `long', as computed by sizeof. */
#define SIZEOF_LONG 8

/* The size of `long long', as computed by sizeof. */
#define SIZEOF_LONG_LONG 8
