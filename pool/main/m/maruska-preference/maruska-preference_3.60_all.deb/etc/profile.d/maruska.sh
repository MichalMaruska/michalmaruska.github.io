# -*- sh -*-

# This is for interactive ?

export HIGHLIGHT_OPTIONS="--style=oxygenated"

export EDITOR=emacsclient
export VISUAL=emacsclient
#export EDITOR=emacs
#export VISUAL=emacs


# todo: move into profile.d/maruska.sh
export LESSKEY_SYSTEM=/etc/lesskey.binary
export LESSOPEN="|lesspipe %s"


if [ "x${preference_dir-}" = "x" ]; then
    source /etc/env
fi

# if solved:
[ "x${preference_dir-}" != "x" ] && source $preference_dir/aliases/top

source  ${preference_dir}/ls-themes/COLORS.green


export MAKEFLAGS="--format=color"
