

create or replace function texify(text)
returns text
as '$libdir/texify.so','texify' language 'c';


select texify('1$1_2');
