



(bind-keys my-emacs-keymap
  "b" 'emacs-beta
  "m" 'emacs-mmc
  "a" 'emacs-attach

  "s" 'emacs-session-open
  "0" 'emacs0
  "1" 'emacs1
  "2" 'emacs2
  "3" 'emacs3
  "4" 'emacs4
  )
