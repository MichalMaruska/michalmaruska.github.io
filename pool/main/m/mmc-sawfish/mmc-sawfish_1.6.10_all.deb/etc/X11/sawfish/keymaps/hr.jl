(require 'mmc.xterm)
(bind-keys my-xterm-keymap
  "t" 'rsh
  "r" 'root
  "p" 'postgres
  "o" 'postgres2

  "b" 'beta
  "d" 'debian
  "m" 'mmc
  "a" 'access-log
  "s" 'access-log2
  "e" 'ebay
                                        ; "M" 'ebay
  )
