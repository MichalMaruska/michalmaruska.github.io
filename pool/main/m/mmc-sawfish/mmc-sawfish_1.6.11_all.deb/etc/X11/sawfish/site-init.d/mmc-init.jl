

;; files which provide `commands'
(require 'mmc.xterm)
(require 'mmc.workspace)
(require 'mmc.cycle)
(require 'mmc.extremes)
(require 'mmc.iswitch-window)
(require 'mmc.resize)
(require 'mmc.wid)
(require 'mmc.window)

(setq load-path (nconc load-path (list "/etc/X11/sawfish/keymaps/")))
