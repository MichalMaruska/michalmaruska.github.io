

(require 'mmc.wid)


(bind-keys wid-keymap
  "r" 'wid-remove-wid-from-window)

