Debian Zsh TODO
===============

After the Buster-Release
------------------------

* Remove alternatives system properly
* Change zsh-dev to Arch:all (requires probably non-trivial reordering
  in debian/rules)

Decisions
---------

* Do we want to continue providing a static build (zsh-static)?
